import getAge from "get-age";

console.log(getAge('2006-07-13'))